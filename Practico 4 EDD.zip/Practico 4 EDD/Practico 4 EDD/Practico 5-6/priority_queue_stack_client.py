
from priority_queue_stack import PriorityQueueStack 

cola_prioridad = PriorityQueueStack()
cola_prioridad.push("C")
cola_prioridad.push("R")
cola_prioridad.push("J")
cola_prioridad.push("B")
cola_prioridad.push("A")

print(cola_prioridad._pila)
print("*"*60)

print(cola_prioridad.top())
print(cola_prioridad._pila)
print("*"*60)


print(cola_prioridad.__len__())
print("*"*60)

ele_rem = cola_prioridad.pop()
print("Pop", ele_rem)
print(cola_prioridad._pila)

