

from array import array
from site import venv
from typing import Any, Tuple
from data_structures import PriorityQueueBase
from data_structures import ArrayStack

class PriorityQueueStack(PriorityQueueBase):
    
    def __init__(self):
        self._pila = []
        self._ultimo = 1
        
    def __len__(self) -> int:

        cant = len(self._pila)
        return cant
    
    
    def is_empty(self) -> bool:

        return len(self._pila) == 0 

    
    def push(self, v: Any) -> None:
        k = self._ultimo
        self._pila.append(self._Item(k,v))
        self._ultimo -= 1

    
    def top(self):
        
        if self.is_empty(): 
            raise Exception("Estructura vacía. No se puede continuar")
        
        minimo = list()
        min = self._pila[0]
        for i in range(len(self._pila)):
            if self._pila[i]._key <  min._key:
                min = self._pila[i]
        
        minimo.append(min._key)
        minimo.append(min._value)
        m = tuple(minimo)         
        return m



    def pop(self):

        if self.is_empty(): 
            raise Exception("Estructura vacía. No se puede continuar")
        
        minimo = list()
        min = self._pila[0]
        for i in range(len(self._pila)):
            if self._pila[i]._key <  min._key:
                min = self._pila[i]
        self._pila.remove(min) 
        minimo.append(min._key)
        minimo.append(min._value)
        m = tuple(minimo)         
        return m
        

       
           

        