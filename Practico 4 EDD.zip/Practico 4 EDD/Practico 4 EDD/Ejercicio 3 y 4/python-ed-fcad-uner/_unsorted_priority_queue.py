
from re import M
from typing import Any, Tuple
from data_structures import PriorityQueueBase
from _unsorted_priority_queue_abstract import UnsortedPriorityQueueAbstract 

class UnsortedPriorityQueue(PriorityQueueBase):
    
    def __init__(self):
        self._lista = [] 
        
    def __len__(self) -> int:
        """ Devuelve la cantidad de elementos en la estructura.
        Returns:
        int: Cantidad de elementos en la estructura. 0 en caso que esté vacía.
        """
        cant = len(self._lista)
        return cant
    
    
    def is_empty(self) -> bool:
        """ Indica si la estructura está vacía o no.
        Returns:
        bool: True si está vacía. False en caso contrario.
        """
        return len(self._lista) == 0 


    
    def add(self, k: Any, v: Any) -> None:
        """ Inserta un nuevo ítem al final de la estructura.
        Args:
        k (Any): Clave que determina la prioridad del ítem.
        v (Any): Valor del ítem.
        """
        self._lista.append(self._Item(k,v))
    
    def min(self) -> Tuple[Any]:
        """ Devuelve una tupla conformada por la clave y valor del ítem con menor valor de
        clave.
        Raises:
        Exception: Arroja excepción si se invoca cuando la estructura está vacía.
        Returns:
        Tuple[Any]: Tupla de dos elementos: Clave y Valor del ítem.
        """
        
        if self.is_empty(): 
            raise Exception("Estructura vacía. No se puede continuar")
        
        minimo = list()
        min = self._lista[0]
        for i in range(len(self._lista)):
            if self._lista[i]._key <  min._key:
                min = self._lista[i]
        
        minimo.append(min._key)
        minimo.append(min._value)
        m = tuple(minimo)         
        return m
    
    def remove_min(self) -> Tuple[Any]:
        """ Quita de la estructura el ítem con menor valor de clave.
        Raises:
        Exception: Arroja excepción si se invoca cuando la estructura está vacía.
        Returns:
        Tuple[Any]: Tupla de dos elementos: Clave y Valor del ítem.
        """
        
        if self.is_empty(): 
            raise Exception("Estructura vacía. No se puede continuar")
        
        minimo = list()
        min = self._lista[0]
        for i in range(len(self._lista)):
            if self._lista[i]._key <  min._key:
                min = self._lista[i]
        self._lista.remove(min) 
        minimo.append(min._key)
        minimo.append(min._value)
        m = tuple(minimo)         
        return m    

        