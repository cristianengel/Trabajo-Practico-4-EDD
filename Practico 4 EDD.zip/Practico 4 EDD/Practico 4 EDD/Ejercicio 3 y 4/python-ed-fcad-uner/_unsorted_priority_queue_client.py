
from _unsorted_priority_queue import UnsortedPriorityQueue 
from data_structures.linear.util import h1, h2

def unsorted_priority_queue_client():
    """Pone a prueba UnsortedPriorityQueue y todos sus métodos"""
    h1("UnsortedPriorityQueue")
    cola_prioridad = UnsortedPriorityQueue()
    

    h2("Metodo add: Inserta un nuevo ítem al final de la estructura.")
    cola_prioridad.add(6,19)
    cola_prioridad.add(3,22)
    cola_prioridad.add(9,11)
    cola_prioridad.add(1,2)
    print(cola_prioridad._lista)
    
    h2("Metodo len: cantidad de elementos en la estructura")
    print(cola_prioridad.__len__())
    
    h2("Metodo IsEmpty: Indica si la estructura está vacía o no.")
    print(cola_prioridad.is_empty())
    
    h2("Metodo Min: Devuelve una tupla conformada por la clave y valor del ítem con menor valor de clave.")
    print(cola_prioridad.min())
    print(cola_prioridad._lista)
    
    h2("Remove Min: Quita de la estructura el ítem con menor valor de clave.")
    print(cola_prioridad.remove_min())
    print(cola_prioridad._lista)


if __name__ == '__main__':  
    unsorted_priority_queue_client()