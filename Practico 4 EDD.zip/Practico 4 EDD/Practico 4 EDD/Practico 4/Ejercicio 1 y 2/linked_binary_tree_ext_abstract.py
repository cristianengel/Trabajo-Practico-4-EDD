from abc import ABC, abstractmethod
from typing import Any, List, Union
from data_structures import BinaryTreeNode

class LinkedBinaryTreeExtAbstract(ABC):
    @abstractmethod
    def hermanos(self, nodo1 : BinaryTreeNode, nodo2: BinaryTreeNode) -> bool:
        pass

    @abstractmethod
    def hojas(self) -> List[Any]:
        pass

    @abstractmethod
    def internos(self) -> List[Any]:
   
        pass

    @abstractmethod
    def profundidad(self, nodo : BinaryTreeNode) -> int:
        pass

    @abstractmethod
    def altura(self, nodo : BinaryTreeNode) -> int:
        pass
    