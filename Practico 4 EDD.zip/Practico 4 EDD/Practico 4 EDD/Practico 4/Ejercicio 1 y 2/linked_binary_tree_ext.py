from linked_binary_tree import LinkedBinaryTree
from linked_binary_tree_ext_abstract import LinkedBinaryTreeExtAbstract
from binary_tree_node import BinaryTreeNode

class LinkedBinaryTreeExt(LinkedBinaryTree):
    
    def hermanos(self, nodo1 : BinaryTreeNode, nodo2: BinaryTreeNode) -> bool:
        pass