from typing import Any, Union
from list_node import ListNode

class LinkedQueue:
    
    def __init__(self) -> None:
        self._front: Union[ListNode, None] = None
        self._back: Union[ListNode, None] = None
        self._size : int = 0
    
    def __len__(self) -> int:
        return self._size
    
    def __str__(self) -> str:
        
        #Si la estructura está vacía => retorno siempre lo mismo.
        if self.is_empty():
            return "LinkedQueue()"
        
        resultado = "" # inicializo resultado con el string vacío

        #Me quedo en actual con el elemento ubicado en el frente
        actual = self._front
        while actual:
            # proceso el elemento del nodo actual
            resultado += str(actual.element) + ", "
            
            # establezco el siguiente nodo como nodo actual
            actual = actual.next 
        
        #Quito los dos últimos caracteres del string    
        resultado = resultado[:len(resultado)-2]
        
        return f"LinkedQueue({resultado})"
        
    def is_empty(self) -> bool:
        return self._size == 0
    
    def is_full(self) -> bool:
        return False
    
    def first(self) -> Any:

        if self.is_empty(): 
            raise Exception("Estructura vacía. No se puede continuar")
        
        return self._front.element
    
    def dequeue(self) -> Any:
 
        if self.is_empty():
            raise Exception("Estructura vacía. No se puede continuar")
        
        resultado = self._front
        self._front = self._front.next
        self._size -= 1
        return resultado
    
    def enqueue(self, elem: Any) -> None:
 
        nuevo_nodo = ListNode(elem, None)
        
        if self.is_empty():
            self._front = nuevo_nodo
            self._back = nuevo_nodo
        else:
            self._back.next = nuevo_nodo
            self._back = self._back.next
            
        self._size += 1