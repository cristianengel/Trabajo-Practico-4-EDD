from _heap_queue import HeapQueue

heap_queue = HeapQueue()

heap_queue.enqueue(2, "r")
heap_queue.enqueue(3, "w")
heap_queue.enqueue(5, "q")
heap_queue.enqueue(3, "e")
heap_queue.enqueue(6, "y")
heap_queue.enqueue(4, "g")
heap_queue.enqueue(7, "d")
heap_queue.enqueue(1, "v")

heap_queue.dequeue()

print(f"Primer elemento: {heap_queue.first()}")

print(f"Está vacia: {heap_queue.is_empty()}")

print(f"Longitud heap queue: {heap_queue.__len__()}")