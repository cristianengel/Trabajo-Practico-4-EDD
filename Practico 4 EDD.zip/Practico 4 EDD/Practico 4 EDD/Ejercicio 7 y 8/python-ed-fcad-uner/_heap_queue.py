from data_structures import ArrayHeap
from data_structures import ArrayQueue

class HeapQueue(ArrayQueue):
    
    def __init__(self) -> None:
        self._array_heap = ArrayHeap()
        
    def __len__(self):
      return len(self._array_heap) 
  
    def is_empty(self):
        return (self._array_heap.is_empty())
    
    def first(self):
        return self._array_heap.min()
    
    def dequeue(self):
        return self._array_heap.remove_min()
    
    def enqueue(self, k: any, elem: any):
        self._array_heap.add(k, elem)